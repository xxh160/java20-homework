public interface Gendered{
	int MALE = 0, FEMALE = 1;
	int getGender();
}