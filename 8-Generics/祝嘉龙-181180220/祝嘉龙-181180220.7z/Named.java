public interface Named{
	String getName();
}